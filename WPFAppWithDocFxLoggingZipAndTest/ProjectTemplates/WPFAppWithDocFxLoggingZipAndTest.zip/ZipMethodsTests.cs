﻿using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using System.IO.Compression;

namespace $safeprojectname$
{
    [TestClass()]
    public class ZipMethodsTests
    {

        [TestMethod()]
        public void AddFileToZipTest()
        {
        }
    }
}
